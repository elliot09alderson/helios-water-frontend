import Home from "./pages/Home";
import React from "react";

const App = () => {
  return (
    <div>
      
      <Home />
    </div>
  );
};

export default App;
