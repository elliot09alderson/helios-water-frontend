import React from "react";

import SwiperCarousel from "../components/Swiper";
import Navbar from "../components/Navbar";
import logo1 from "/logo/logo1.png";
import logo2 from "/logo/logo2.png";
import logo3 from "/logo/logo3.png";
import logo4 from "/logo/logo3.png";
import rise from "/rise.png";
import bottle from "/bottle.png";
import bottle2 from "/bottle2.png";
const Home = () => {
  const logoArr = [
    { logo: logo1, text: "Vedica - Himalayan Spring Water" },
    { logo: logo2, text: "Carbonated Soft Drinks" },
    { logo: logo3, text: "Carbonated Soft Drinks" },
  ];
  return (
    <div className=" ">
      <Navbar />
      <SwiperCarousel />

      <section className="lg:px-96  w-full flex flex-col items-center gap-12 p-20  bg-gradient-to-r from-[#74ebd5] to-[#acb6e5] mt-12">
        <div className="flex items-center flex-col gap-4  justify-center w-full">
          <h1 className="text-fuchsia-400 font-bold text-5xl italic font-[new]">
            Rise Above the blues
          </h1>
          <p className="text-lg italic text-gray-400">
            A household name for decades gone, decades to come.
          </p>
        </div>

        <div className="w-[1200px]  flex justify-center items-center gap-5">
          <div className="w-64 h-full flex flex-col gap-5">
            {logoArr.map((item, idx) => (
              <div className="w-48 flex flex-col gap-4 items-center justify-center">
                <img
                  src={item.logo}
                  alt=""
                  className="object-cover w-16 bg-white rounded-lg"
                />
                <h2 className="text-center text-sm text-gray-300    ">
                  {item.text}
                </h2>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center w-full">
            <div className="w-full h-[800px] rounded-4xl bg-white pl-32">
              <p>Bisleri Packaged Drinking WaterBisleri Bottles</p>
              <img src="" alt="" />
              <h2>Values Quality with Care</h2>
              <p>
                Bisleri Packaged Drinking Water stands apart with its promise of
                goodness that goes through rigorous 10 STEP QUALITY PROCESS and
                90 TE drop is safe, pure and hygienic to the core and meets the
                quality set by the Bureau of Indian Standards (BIS).
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="relative lg:px-[400px] flex flex-col items-center">
        <img
          src={bottle}
          className="w-[600px] -rotate-45 object-cover absolute top-24 left-24"
          alt=""
        />
        <img
          src={bottle}
          className="w-[600px] rotate-3 object-cover absolute top-24 rotate-45 duration-2000 right-24"
          alt=""
        />{" "}
        <img
          src={bottle2}
          className="w-[600px] rotate-45 object-cover absolute top-[800px]   right-[100px]"
          alt=""
        />
        <img
          src={bottle2}
          className="w-[600px] -rotate-45 object-cover absolute top-[800px]  left-[100px]"
          alt=""
        />
        <img src={rise} alt="" className="object-cover w-[1400px]" />
      </section>
    </div>
  );
};

export default Home;
